class Store < ApplicationRecord
	validates :Store_Name, presence: true, uniqueness: true
	validates :Store_Location, presence: true
end
